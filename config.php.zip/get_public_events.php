<?php
require_once 'config.php';

$sql = "SELECT event_date FROM events";
$result = $conn->query($sql);

$events = [];
while ($row = $result->fetch_assoc()) {
    $date = $row['event_date'];
    $events[$date] = true;
}

header('Content-Type: application/json');
echo json_encode($events);
?>
