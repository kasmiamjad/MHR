<?php
session_start();
if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit;
}

require_once 'config.php';

// Enable error reporting
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
header('Content-Type: application/json'); // Ensure the content is JSON

// Fetch data from POST request
$date = $_POST['date'] ?? null;
$name = $_POST['name'] ?? null;
$event = $_POST['event'] ?? null;

if (!$date || !$name || !$event) {
    echo json_encode(['success' => false, 'message' => 'Missing required fields']);
    exit;
}

try {
   // Check if event already exists for this date
$sql = "SELECT id FROM events WHERE event_date = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $date);
$stmt->execute();

// Bind the result to a variable
$stmt->bind_result($id);
$stmt->store_result(); // Store the result so we can check num_rows

if ($stmt->num_rows > 0) {
    // Update existing event
    $sql = "UPDATE events SET guest_name = ?, event_details = ? WHERE event_date = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sss", $name, $event, $date);
} else {
    // Insert new event
    $sql = "INSERT INTO events (event_date, guest_name, event_details) VALUES (?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sss", $date, $name, $event);
}

    

    $success = $stmt->execute();
    echo json_encode(['success' => $success]);
} catch (Exception $e) {
    // Return error in JSON format
    echo json_encode(['success' => false, 'message' => 'Database error: ' . $e->getMessage()]);
}
