<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

session_start();
if(!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true) {
    header("Location: login.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Resort Booking Calendar</title>
    <style>
        * {
            box-sizing: border-box;
            font-family: Arial, sans-serif;
        }

        body {
            margin: 20px;
            background-color: #f5f5f5;
        }

        .calendar {
            max-width: 800px;
            margin: 0 auto;
            background: white;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
            padding: 20px;
        }

        .calendar-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 10px;
            background: #4CAF50;
            color: white;
            border-radius: 4px;
        }

        .calendar-header button {
            background: none;
            border: none;
            color: white;
            font-size: 20px;
            cursor: pointer;
            padding: 5px 10px;
        }

        .calendar-grid {
            display: grid;
            grid-template-columns: repeat(7, 1fr);
            gap: 5px;
            padding: 10px 0;
        }

        .calendar-day {
            aspect-ratio: 1;
            border: 1px solid #ddd;
            padding: 5px;
            text-align: center;
            cursor: pointer;
            position: relative;
            background: white;
        }

        .calendar-day:hover {
            background: #f0f0f0;
        }

        .calendar-day.has-event {
            background: indianred;
        }

        .event-info {
            font-size: 10px;
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
        }

        .modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0,0,0,0.5);
        }

        .modal-content {
            background: white;
            width: 90%;
            max-width: 500px;
            margin: 50px auto;
            padding: 20px;
            border-radius: 8px;
        }

        .form-group {
            margin-bottom: 15px;
        }

        .form-group label {
            display: block;
            margin-bottom: 5px;
        }

        .form-group input {
            width: 100%;
            padding: 8px;
            border: 1px solid #ddd;
            border-radius: 4px;
        }

        .button-group {
            display: flex;
            justify-content: space-between;
            margin-top: 20px;
        }

        button {
            padding: 8px 15px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }

        .save-btn {
            background: #4CAF50;
            color: white;
        }

        .delete-btn {
            background: #f44336;
            color: white;
        }

        .cancel-btn {
            background: #9e9e9e;
            color: white;
        }

        @media (max-width: 600px) {
            .calendar {
                padding: 10px;
            }

            .calendar-day {
                font-size: 14px;
            }

            .event-info {
                font-size: 9px;
            }
        }
    </style>
</head>
<body>
    <div class="calendar">
        <div class="calendar-header">
            <button onclick="previousMonth()">&lt;</button>
            <h2 id="monthDisplay"></h2>
            <button onclick="nextMonth()">&gt;</button>
        </div>
        <div class="calendar-grid" id="calendarGrid"></div>

        <div class="calendar-header">
    <button onclick="previousMonth()">&lt;</button>
    <h2 id="monthDisplay"></h2>
    <button onclick="nextMonth()">&gt;</button>
    <button onclick="logout()" style="background: #f44336; padding: 5px 10px; border-radius: 4px;">Logout</button>
</div>
    </div>

    <div class="modal" id="eventModal">
        <div class="modal-content">
            <h3>Booking Details</h3>
            <form id="eventForm">
                <input type="hidden" id="selectedDate">
                <div class="form-group">
                    <label for="name">Guest Name:</label>
                    <input type="text" id="name" required>
                </div>
                <div class="form-group">
                    <label for="event">Event Details:</label>
                    <input type="text" id="event" required>
                </div>
                <div class="button-group">
                    <button type="button" class="delete-btn" onclick="deleteEvent()" id="deleteBtn" style="display:none">Delete</button>
                    <button type="button" class="cancel-btn" onclick="closeModal()">Cancel</button>
                    <button type="submit" class="save-btn">Save</button>
                </div>
            </form>
        </div>
    </div>

    <script>
        let currentDate = new Date();
        let events = {};

        function renderCalendar() {
            const grid = document.getElementById('calendarGrid');
            const monthDisplay = document.getElementById('monthDisplay');

            // Clear previous calendar
            grid.innerHTML = '';

            // Set month display
            const monthYear = currentDate.toLocaleString('default', { month: 'long', year: 'numeric' });
            monthDisplay.textContent = monthYear;

            // Add day headers
            const days = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
            days.forEach(day => {
                const dayHeader = document.createElement('div');
                dayHeader.textContent = day;
                dayHeader.style.fontWeight = 'bold';
                grid.appendChild(dayHeader);
            });

            // Get first day of month and total days
            const firstDay = new Date(currentDate.getFullYear(), currentDate.getMonth(), 1);
            const lastDay = new Date(currentDate.getFullYear(), currentDate.getMonth() + 1, 0);

            // Add empty cells for days before start of month
            for (let i = 0; i < firstDay.getDay(); i++) {
                grid.appendChild(document.createElement('div'));
            }

            // Add days of month
            for (let day = 1; day <= lastDay.getDate(); day++) {
                const dayCell = document.createElement('div');
                dayCell.className = 'calendar-day';
                dayCell.textContent = day;

                const dateStr = `${currentDate.getFullYear()}-${(currentDate.getMonth()+1).toString().padStart(2, '0')}-${day.toString().padStart(2, '0')}`;

                if (events[dateStr]) {
                    dayCell.classList.add('has-event');
                    const eventInfo = document.createElement('div');
                    eventInfo.className = 'event-info';
                    eventInfo.textContent = events[dateStr].name;
                    dayCell.appendChild(eventInfo);
                }

                dayCell.onclick = () => openModal(dateStr);
                grid.appendChild(dayCell);
            }
        }

        function previousMonth() {
            currentDate.setMonth(currentDate.getMonth() - 1);
            renderCalendar();
        }

        function nextMonth() {
            currentDate.setMonth(currentDate.getMonth() + 1);
            renderCalendar();
        }

        function openModal(date) {
            document.getElementById('selectedDate').value = date;
            const modal = document.getElementById('eventModal');
            const nameInput = document.getElementById('name');
            const eventInput = document.getElementById('event');
            const deleteBtn = document.getElementById('deleteBtn');

            if (events[date]) {
                nameInput.value = events[date].name;
                eventInput.value = events[date].event;
                deleteBtn.style.display = 'block';
            } else {
                nameInput.value = '';
                eventInput.value = '';
                deleteBtn.style.display = 'none';
            }

            modal.style.display = 'block';
        }

        function closeModal() {
            document.getElementById('eventModal').style.display = 'none';
        }

        function deleteEvent() {
            const date = document.getElementById('selectedDate').value;

            // AJAX call to delete event
            fetch('delete_event.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: `date=${date}`
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    delete events[date];
                    renderCalendar();
                    closeModal();
                } else {
                    alert('Error deleting event');
                }
            });
        }

document.getElementById('eventForm').onsubmit = function(e) {
    e.preventDefault();
    const date = document.getElementById('selectedDate').value;
    const name = document.getElementById('name').value;
    const event = document.getElementById('event').value;

    // AJAX call to save event
    fetch('save_event.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: `date=${date}&name=${name}&event=${event}`
    })
    .then(response => response.text()) // Get raw response text
    .then(text => {
        console.log(text); // Log response for debugging
        return JSON.parse(text); // Parse JSON if valid
    })
    .then(data => {
        if (data.success) {
            events[date] = { name, event };
            renderCalendar();
            closeModal();
        } else {
            alert(data.message || 'Error saving event');
        }
    })
    .catch(error => {
        console.error('Error parsing JSON:', error);
        alert('An unexpected error occurred. Check the console for details.');
    });
};


        // Initial load of calendar
        renderCalendar();


        function handleUnauthorized(response) {
    if (response.status === 401) {
        window.location.href = 'login.php';
        return;
    }
    return response;
}

        // Load existing events
        fetch('get_events.php')
      .then(handleUnauthorized)
      .then(response => response.json())
      .then(data => {
          events = data;
          renderCalendar();
      });




            function logout() {
    window.location.href = 'logout.php';
}
    </script>
</body>
</html>
