<?php
session_start();

// Add these credentials to your database or change as needed
$valid_username = "admin";
$valid_password = "admin123"; // In production, use password_hash()

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['username'];
    $password = $_POST['password'];

    if ($username === $valid_username && $password === $valid_password) {
        $_SESSION['logged_in'] = true;
        $_SESSION['username'] = $username;
        header("Location: index.php");
        exit;
    } else {
        $_SESSION['error'] = "Invalid username or password";
        header("Location: login.php");
        exit;
    }
}
?>
