<?php
session_start();
if(!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true) {
    http_response_code(401);
    exit;
}
require_once 'config.php';

$sql = "SELECT event_date, guest_name, event_details FROM events";
$result = $conn->query($sql);

$events = [];
while ($row = $result->fetch_assoc()) {
    $date = $row['event_date'];
    $events[$date] = [
        'name' => $row['guest_name'],
        'event' => $row['event_details']
    ];
}

header('Content-Type: application/json');
echo json_encode($events);
