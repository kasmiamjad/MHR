<?php
session_start();
if(!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true) {
    http_response_code(401);
    exit;
}

require_once 'config.php';

$date = $_POST['date'];
$name = $_POST['name'];
$event = $_POST['event'];

// Check if event already exists for this date
$sql = "SELECT id FROM events WHERE event_date = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $date);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    // Update existing event
    $sql = "UPDATE events SET guest_name = ?, event_details = ? WHERE event_date = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sss", $name, $event, $date);
} else {
    // Insert new event
    $sql = "INSERT INTO events (event_date, guest_name, event_details) VALUES (?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sss", $date, $name, $event);
}

$success = $stmt->execute();

header('Content-Type: application/json');
echo json_encode(['success' => $success]);
