<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Resort Availability Calendar</title>
    <style>
        * {
            box-sizing: border-box;
            font-family: Arial, sans-serif;
        }

        body {
            margin: 20px;
            background-color: #f5f5f5;
        }

        .calendar {
            max-width: 800px;
            margin: 0 auto;
            background: white;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
            padding: 20px;
        }

        .calendar-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 10px;
            background: #4CAF50;
            color: white;
            border-radius: 4px;
        }

        .nav-button {
            background: none;
            border: none;
            color: white;
            font-size: 20px;
            cursor: pointer;
            padding: 5px 10px;
        }

        .calendar-grid {
            display: grid;
            grid-template-columns: repeat(7, 1fr);
            gap: 5px;
            padding: 10px 0;
        }

        .calendar-day {
            aspect-ratio: 1;
            border: 1px solid #ddd;
            padding: 5px;
            text-align: center;
            position: relative;
            background: white;
        }

        .calendar-day.booked {
            background: #ffebee;
            color: #d32f2f;
        }

        .calendar-day.available {
            background: #e8f5e9;
            color: #2e7d32;
        }

        .status-badge {
            font-size: 10px;
            padding: 2px;
            text-align: center;
            position: absolute;
            bottom: 2px;
            left: 2px;
            right: 2px;
            border-radius: 2px;
        }

        .legend {
            display: flex;
            justify-content: center;
            gap: 20px;
            margin-top: 20px;
            padding: 10px;
            background: #fff;
            border-radius: 4px;
        }

        .legend-item {
            display: flex;
            align-items: center;
            gap: 5px;
        }

        .legend-color {
            width: 20px;
            height: 20px;
            border-radius: 4px;
        }

        .contact-info {
            text-align: center;
            margin-top: 20px;
            padding: 10px;
            background: #fff;
            border-radius: 4px;
        }

        @media (max-width: 600px) {
            .calendar {
                padding: 10px;
            }

            .calendar-day {
                font-size: 14px;
            }

            .status-badge {
                font-size: 8px;
            }
        }
    </style>
</head>
<body>
    <div class="calendar">
        <div class="calendar-header">
            <button class="nav-button" onclick="previousMonth()">&lt;</button>
            <h2 id="monthDisplay"></h2>
            <button class="nav-button" onclick="nextMonth()">&gt;</button>
        </div>
        <div class="calendar-grid" id="calendarGrid"></div>

        <div class="legend">
            <div class="legend-item">
                <div class="legend-color" style="background: #e8f5e9;"></div>
                <span>Available</span>
            </div>
            <div class="legend-item">
                <div class="legend-color" style="background: #ffebee;"></div>
                <span>Booked</span>
            </div>
        </div>

        <div class="contact-info">
            <h3>Book Your Stay</h3>
            <p>Contact us to make a reservation:</p>
            <p>📞 Phone: <a href="tel:+1234567890">123-456-7890</a></p>
            <p>📧 Email: <a href="mailto:bookings@yourresort.com">bookings@yourresort.com</a></p>
        </div>
    </div>

    <script>
        let currentDate = new Date();
        let events = {};

        function renderCalendar() {
            const grid = document.getElementById('calendarGrid');
            const monthDisplay = document.getElementById('monthDisplay');

            // Clear previous calendar
            grid.innerHTML = '';

            // Set month display
            const monthYear = currentDate.toLocaleString('default', { month: 'long', year: 'numeric' });
            monthDisplay.textContent = monthYear;

            // Add day headers
            const days = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
            days.forEach(day => {
                const dayHeader = document.createElement('div');
                dayHeader.textContent = day;
                dayHeader.style.fontWeight = 'bold';
                grid.appendChild(dayHeader);
            });

            // Get first day of month and total days
            const firstDay = new Date(currentDate.getFullYear(), currentDate.getMonth(), 1);
            const lastDay = new Date(currentDate.getFullYear(), currentDate.getMonth() + 1, 0);

            // Add empty cells for days before start of month
            for (let i = 0; i < firstDay.getDay(); i++) {
                grid.appendChild(document.createElement('div'));
            }

            // Add days of month
            for (let day = 1; day <= lastDay.getDate(); day++) {
                const dayCell = document.createElement('div');
                dayCell.className = 'calendar-day';
                dayCell.textContent = day;

                const dateStr = `${currentDate.getFullYear()}-${(currentDate.getMonth()+1).toString().padStart(2, '0')}-${day.toString().padStart(2, '0')}`;

                // Check if date is in past
                const currentDateObj = new Date();
                const cellDate = new Date(currentDate.getFullYear(), currentDate.getMonth(), day);

                if (cellDate < new Date(currentDateObj.setHours(0,0,0,0))) {
                    // Past dates
                    dayCell.style.backgroundColor = '#f5f5f5';
                    dayCell.style.color = '#999';
                } else if (events[dateStr]) {
                    // Booked dates
                    dayCell.classList.add('booked');
                    const badge = document.createElement('div');
                    badge.className = 'status-badge';
                    badge.textContent = 'Booked';
                    dayCell.appendChild(badge);
                } else {
                    // Available dates
                    dayCell.classList.add('available');
                    const badge = document.createElement('div');
                    badge.className = 'status-badge';
                    badge.textContent = 'Available';
                    dayCell.appendChild(badge);
                }

                grid.appendChild(dayCell);
            }
        }

        function previousMonth() {
            currentDate.setMonth(currentDate.getMonth() - 1);
            renderCalendar();
            loadEvents();
        }

        function nextMonth() {
            currentDate.setMonth(currentDate.getMonth() + 1);
            renderCalendar();
            loadEvents();
        }

        function loadEvents() {
            fetch('get_public_events.php')
                .then(response => response.json())
                .then(data => {
                    events = data;
                    renderCalendar();
                });
        }

        // Initial load
        loadEvents();
    </script>
</body>
</html>
